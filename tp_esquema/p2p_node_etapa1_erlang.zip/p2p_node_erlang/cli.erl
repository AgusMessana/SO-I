
-module(cli).
-export([loop/0]).

loop() ->
    io:format(">> "),
    case io:get_line("") of
        "id_nodo\n" ->
            io:format("ID del nodo: ~p~n", [node_state:get_node_id()]),
            loop();
        "listar_mis_archivos\n" ->
            node_state:listar_archivos(),
            loop();
        "salir\n" ->
            io:format("Cerrando nodo...~n"),
            halt();
        _ ->
            io:format("Comando desconocido.~n"),
            loop()
    end.
