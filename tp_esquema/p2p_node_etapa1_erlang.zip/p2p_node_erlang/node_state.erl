
-module(node_state).
-export([init/1, get_node_id/0, listar_archivos/0, register_in_registry/0]).

-define(SHARED_DIR, "shared").

init(NodeID) ->
    register(node_state, self()),
    put(node_id, NodeID).

get_node_id() ->
    get(node_id).

listar_archivos() ->
    case file:list_dir(?SHARED_DIR) of
        {ok, Files} ->
            lists:foreach(fun(F) -> io:format("- ~s~n", [F]) end, Files);
        {error, Reason} ->
            io:format("Error abriendo carpeta: ~p~n", [Reason])
    end.

register_in_registry() ->
    io:format("Registrando nodo ~p en nodes_registry.json~n", [get(node_id)]).
