
-module(server).
-export([start/0]).

start() ->
    {ok, ListenSocket} = gen_tcp:listen(12345, [binary, {packet, 0}, {active, false}, {reuseaddr, true}]),
    spawn(fun() -> accept_loop(ListenSocket) end).

accept_loop(ListenSocket) ->
    {ok, Socket} = gen_tcp:accept(ListenSocket),
    spawn(fun() -> handle_client(Socket) end),
    accept_loop(ListenSocket).

handle_client(Socket) ->
    case gen_tcp:recv(Socket, 0) of
        {ok, Data} ->
            io:format("[Entrada TCP] ~p~n", [Data]),
            gen_tcp:close(Socket);
        _ ->
            gen_tcp:close(Socket)
    end.
