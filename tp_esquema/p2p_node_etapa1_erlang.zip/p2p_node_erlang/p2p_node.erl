
-module(p2p_node).
-export([start/1]).

start(NodeID) ->
    io:format("Inicializando nodo: ~p~n", [NodeID]),
    node_state:init(NodeID),
    node_state:register_in_registry(),
    spawn(cli, loop, []),
    server:start().
