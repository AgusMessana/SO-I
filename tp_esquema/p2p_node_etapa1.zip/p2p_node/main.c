
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "cli.h"
#include "server.h"
#include "node_state.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Uso: %s <ID_nodo>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *node_id = argv[1];
    printf("Inicializando nodo: %s\n", node_id);

    init_node_state(node_id);
    register_in_registry();

    pthread_t cli_thread;
    pthread_create(&cli_thread, NULL, cli_loop, NULL);

    start_server();

    pthread_join(cli_thread, NULL);
    return 0;
}
