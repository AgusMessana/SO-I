
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <pthread.h>
#include "node_state.h"

#define SHARED_DIR "./shared"
static pthread_mutex_t archivos_mutex = PTHREAD_MUTEX_INITIALIZER;
static char *node_id = NULL;

void init_node_state(const char *id) {
    node_id = strdup(id);
}

void listar_archivos() {
    pthread_mutex_lock(&archivos_mutex);
    DIR *dir = opendir(SHARED_DIR);
    if (!dir) {
        perror("No se pudo abrir la carpeta compartida");
        pthread_mutex_unlock(&archivos_mutex);
        return;
    }

    struct dirent *ent;
    while ((ent = readdir(dir)) != NULL) {
        if (ent->d_type == DT_REG) {
            printf("- %s\n", ent->d_name);
        }
    }
    closedir(dir);
    pthread_mutex_unlock(&archivos_mutex);
}

const char *get_node_id() {
    return node_id;
}

void register_in_registry() {
    // Simulado por ahora
    printf("Registrando nodo %s en nodes_registry.json\n", node_id);
}
