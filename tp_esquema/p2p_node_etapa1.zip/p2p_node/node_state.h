
#ifndef NODE_STATE_H
#define NODE_STATE_H

void init_node_state(const char *id);
void listar_archivos();
const char *get_node_id();
void register_in_registry();

#endif
