
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "node_state.h"

void *cli_loop(void *arg) {
    char comando[64];
    while (1) {
        printf(">> ");
        fflush(stdout);
        if (!fgets(comando, sizeof(comando), stdin)) continue;

        if (strncmp(comando, "id_nodo", 7) == 0) {
            printf("ID del nodo: %s\n", get_node_id());
        } else if (strncmp(comando, "listar_mis_archivos", 20) == 0) {
            listar_archivos();
        } else if (strncmp(comando, "salir", 5) == 0) {
            printf("Cerrando nodo...\n");
            exit(0);
        } else {
            printf("Comando desconocido.\n");
        }
    }
    return NULL;
}
